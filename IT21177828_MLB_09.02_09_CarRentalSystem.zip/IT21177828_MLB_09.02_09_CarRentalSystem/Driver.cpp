#include <iostream>
#include "Driver.h"
#include "RegisteredUser.h"
#include "Notification.h"
#include "Reservation.h"
using namespace std;

Driver::Driver(int accountNumber, string licenNumber, string address, string bankName ){
    this->accountNumber = accountNumber;
    this->licenNumber = licenNumber;
    this->address = address;
    this->bankName = bankName;
}
void Driver::displayDriverDetails(){
    cout <<"---------------------------------"<<endl;
    cout << "Driver Details : "<<endl;
    cout << "AccountNumber\t: "<< accountNumber<<endl;
    cout << "LicenNumber\t: "<< licenNumber <<endl;
    cout << "Address\t\t: "<< address <<endl;
    cout << "BankName\t: "<< bankName <<endl;
    cout <<"---------------------------------\n"<<endl;  
}
void Driver::updateDriverDetails(int accountNumber, string licenNumber, string address, string bankName){
    this->accountNumber = accountNumber;
    this->licenNumber = licenNumber;
    this->address = address;
    this->bankName = bankName;
}
  
void Driver::reciveNotification(string content2){
    unreadNotifications += content2;
    unreadNotifications +=" \n";
}
void Driver::viewNotification(){
    cout  <<"\nNew notification ::\n"<< unreadNotifications<<endl;         
}

