#include<iostream>
#include<cstring>
using namespace std;


class Driver:public RegisteredUser{	
    private:  
    int accountNumber;
    string licenNumber;
    string address;
    string bankName;    
    string unreadNotifications;
    public:
    Driver(){};
    Driver(int accountNumber, string licenNumber, string address, string bankName );
    void displayDriverDetails();
    void updateDriverDetails(int accountNumber, string licenNumber, string address, string bankName);  
    void reciveNotification(string content2);
    void viewNotification();
    ~Driver(){
        cout << "DRIVER DELETED"<<endl;
    };
};
