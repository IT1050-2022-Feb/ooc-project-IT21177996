#include <iostream>
#include "Issue.h"
#include "RegisteredUser.h"
using namespace std;


void Issue::setIssue(string issue){  
 userIssue = issue;
}

void Issue::displayIssue(){
  cout<<userIssue;
}
void Issue:: updateIssue(){
  
}
void Issue:: removeIssue(){
  
}

