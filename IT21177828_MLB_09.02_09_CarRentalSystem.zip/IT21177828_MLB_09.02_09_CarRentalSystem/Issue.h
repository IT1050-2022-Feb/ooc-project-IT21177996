#include<iostream>
#include<cstring>
using namespace std;

class Issue{
    private:    
    int issueID;
    string userIssue;
    public:
    Issue(){};
    void setIssue(string issue); 
    void displayIssue();
    void updateIssue();
    void removeIssue();
    ~Issue(){};
};
