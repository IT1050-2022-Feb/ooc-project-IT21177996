#include <iostream>
#include "Driver.h"
#include "Notification.h"
#include "Admin.h"
using namespace std;

 Notification::Notification(Driver *toReciver,string content){
      this->toReciver = toReciver;
      this->content = content;
}  
void Notification::sendNotification(){             
        toReciver->reciveNotification(content);
}
