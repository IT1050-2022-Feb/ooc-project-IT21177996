#include<iostream>
#include<cstring>
using namespace std;

class Notification{
    private:    
    string content;    
    public:
    Driver *toReciver;
    Notification(Driver *toReciver,string content);  
    void sendNotification(); 
    ~Notification(){};

};
