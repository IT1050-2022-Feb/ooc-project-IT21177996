#include "Customer.h"
#include "Payment.h"
#include <iostream>
#include<string>


#include "OOC_ASSIGNMENT_02.cpp"


Customer::Customer()
{
    CustomerID = 0;
    DateOfBirth = "NULL";
    Address = "NULL";
    numberOfReservation = 0;
}
void Customer::setCustomerDetails(int customerID, string dateOfBirth, string address)
{
    CustomerID = customerID;
    DateOfBirth = dateOfBirth;
    Address = address;
    /*   FD = Fb;
       reservation1 = Rsvn1;
       payment = pyt;*/
}
void Customer::setCustomerDetails_1(Payment* Payment, Feedback* fd)

{
    Payment = payment;
    FD = fd;
}

void Customer::DisplayCustomerDetails()
{
    cout << "Customer ID : " << CustomerID << endl;
    cout << "Date Of Birth : " << DateOfBirth << endl;
    cout << "Address : " << Address << endl;

}

void Customer::UpdateCustomerDetails()
{

}

void  Customer::viewFAQ(Faq* f) {

    f->printFAQ();

}
void Customer::viewNOtification(Notification* n)
{
    CustomerID = n->Notification();
}
//Reservation::Reservation(int customerId,string customerName,string pickupDate,string dropOffDate,int numberOfDates)
void Customer::createReservation(Car* car)
{
    string pickupDate;
    string dropOffDate;
    int numberOfDates;
    cout << "Enter pickupDate:\t";
    cin >> pickupDate;
    cout << "Enter dropOffDate:\t";
    cin >> dropOffDate;
    cout << "Enter number of days\t";
    cin >> numberOfDates;
    Reservation* newReservation = new Reservation(CustomerID, name, pickupDate, dropOffDate, numberOfDates);
    reservation[numberOfReservation] = newReservation;
    numberOfReservation++;
}
/*
Customer nimal =
  */
void Customer::displayCoustomer()
{
    for (int i = 0; i < numberOfReservation; i++)
        reservation[i]->printReservationDetails();
}
void getCustomerDetails() {
}
Customer::~Customer() {
    cout << "customer Delete " << endl;
}
void Customer::addADriver(int resNo, Driver driver) {
    reservation[resNo]->addADriver(driver, CustomerID);
}