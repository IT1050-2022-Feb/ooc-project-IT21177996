#pragma 

#include <iostream>
#include<string>


#include "FAQ.h"
#include "Payment.h"
#include "Reservation.h"
#include "RegisteredUser.h"


#define SIZE 10




class Customer : public RegisteredUser
{

protected:
    string name;
    int CustomerID;
    string DateOfBirth;
    string Address;

private:

    Payment* payment;                   // Aggregation Relationship
    Reservation* reservation[SIZE];  //agerregation Relationship
    int numberOfReservation;
    Feedback* FD;                    //an object of Feedback as attribute

public:


    Customer();
    void setCustomerDetails(int customerID, string dateOfBirth, string address);
    void getCustomerDetails();
    void setCustomerDetails_1(Paymet* Payment, Feedback* fd);
    void DisplayCustomerDetails();
    void UpdateCustomerDetails();
    void viewFAQ(FAQ* f);            //this function use fore the depedency
    void createReservation(Car* car);
    void displayCoustomer();
    void viewNOtification(Notification* n);
    void addADriver(int resNo, Driver driver);

    ~Customer();

};
/*
Car car1(......);
Customer nimal = new Customer(.....);
nimal->createReservation(car1,......);
Driver driver1("saman"......)
nimal->addADriver(1,driver1);
*/

