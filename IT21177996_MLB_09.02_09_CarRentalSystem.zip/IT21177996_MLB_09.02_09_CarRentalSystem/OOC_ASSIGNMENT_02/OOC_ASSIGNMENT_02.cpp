// OOC_ASSIGNMENT_02.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include<string>
#include "FAQ.h"
#include "Payment.h"
#include "Reservation.h"




using namespace std;

class RegisteredUser;
class Customer;
class Payment;
class Feedback;
class Admin;
class CardPayment;

int main()
{
	RegisteredUser* reg; //usding danimic object
	Customer* cust;
	Payment* pymnt;
	Feedback* feedbk;
	Admin* admin1;
	CardPayment* cardpay1;

	reg = new RegisteredUser();
	cust = new Customer();
	pymnt = new Payment();
	feedbk = new Feedback();
	admin1 = new Admin();
	cardpay1 = new CardPayment();

	Car* gt2 = new Car("CBB-1980", "AIA", "2022-10-19", "Porche", "GT2 RS MR", 12000);
	Car* la = new Car("CAA-1390", "Union", "2022-12-31", "Ferrari", "LaFerrari", 85000);
	Insurance* uni = new Insurance("Union", "2022-12-31");
	Insurance* aia = new Insurance("AIA", "2022-10-19");
	Reservation* res1 = new Reservation(1, "malith", "2022-05-01", "2022-05-07", 6);
	Reservation* res2 = new Reservation(2, "dilshan", "2022-04-10", "2022-04-18", 8);

	Reservation* reservationList[2];
	reservationList[0] = res1;
	reservationList[1] = res2;
	Report* report = new Report(*reservationList, 2);
	report->printReport();


	cust->createReservation(gt2);
	reg->DisplayRegisteredDetails();
	pymnt->displayPaymentDetails();
	pymnt->CalPayment();
	cust->displayCoustomer();


	delete reg;
	delete cust;
	delete pymnt;
	delete cust;



}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
