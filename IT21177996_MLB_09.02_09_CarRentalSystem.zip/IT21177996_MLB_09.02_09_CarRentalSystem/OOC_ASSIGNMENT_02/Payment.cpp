#include "Payment.h"
#include <iostream>
#include<string>
#include "OOC_ASSIGNMENT_02.cpp"
Payment::Payment()
{
    PyamentValue = 0;
    PaymentID = 0;
    PaymentType = "NULL";
}

Payment::Payment(float  paymentValue, int paymentID, string paymentType)
{
    PyamentValue = paymentValue;
    PaymentID = paymentID;
    PaymentType = paymentType;
}

void Payment::displayPaymentDetails()
{
    cout << " Pyament Value : " << PyamentValue << endl;
    cout << " paymentID : " << PaymentID << endl;
    cout << " paymentType : " << PaymentType << endl;
}
