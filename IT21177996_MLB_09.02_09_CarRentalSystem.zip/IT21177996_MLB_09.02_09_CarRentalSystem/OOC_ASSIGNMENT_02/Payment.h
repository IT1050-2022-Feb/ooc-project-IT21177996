#pragma once
#include<string>
#include <iostream>

#include "Payment.h"
#include "Reservation.h"


//Payment class
class Payment
{
protected:

    float  PyamentValue;
    int PaymentID;
    string PaymentType;
public:

    Payment();
    Payment(float  paymentValue, int paymentID, string paymentType);
    void CalPayment();
    void displayPaymentDetails();
    void StorePayementDetails();

    ~Payment();
};


