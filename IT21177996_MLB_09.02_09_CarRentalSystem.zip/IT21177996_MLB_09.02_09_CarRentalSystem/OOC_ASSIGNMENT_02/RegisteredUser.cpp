
#include <iostream>
#include<string>


#include "OOC_ASSIGNMENT_02.cpp"
#include "RegisteredUser.h"



//RegisterUser default constructor
RegisteredUser::RegisteredUser()
{
    name = 'NULL';
    PhoneNumber = 0;
    NIC = 'NULL';
    Gender = 'NULL';
    UserID = 'NULL';
    Email = 'NULL';
}

//RegisterUser class Overload Constracter
RegisteredUser::RegisteredUser(string Name, int phoneNumber, string nIC, string gender, string email)
{
    name = Name;
    PhoneNumber = phoneNumber;
    NIC = nIC;
    Gender = nIC;
    UserID = gender;
    Email = email;
}

//RegisterUser class method
void RegisteredUser::SetRegisteruserDetails(string Name, int phoneNumber, string nIC, string gender, string email)
{
    name = Name;
    PhoneNumber = phoneNumber;
    NIC = nIC;
    Gender = nIC;
    UserID = gender;
    Email = email;
}

void RegisteredUser::DisplayRegisteredDetails()
{
    cout << "Name : " << name << endl;
    cout << "PhoneNumber : " << PhoneNumber << endl;
    cout << "NIC : " << NIC << endl;
    cout << " Gender : " << Gender << endl;
    cout << "UserID : " << UserID << endl;
    cout << "Email : " << Email << endl;

}

//RegisterUser class Destructor
RegisteredUser::~RegisteredUser() {

    cout << "Deeleting RegisterUser" << name << endl;
}

//RegisteredUser class add issue
void RegisteredUser::addIssue(Issue* is1, string issue) {
    is = is1;
    pIssue = issue;
    is->setIssue(pIssue);
}
