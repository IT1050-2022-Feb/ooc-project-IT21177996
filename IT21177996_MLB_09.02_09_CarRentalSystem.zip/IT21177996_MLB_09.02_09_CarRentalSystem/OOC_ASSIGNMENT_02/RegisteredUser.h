#pragma once

#include <iostream>
#include<string>
using namespace std;

//RegisteredUser class
class RegisteredUser {
protected:

    string name;
    int PhoneNumber;
    string NIC;
    string Gender;
    string UserID;
    string Email;
private:
    Issue* is;
    string pIssue;
public:
    RegisteredUser();
    RegisteredUser(string Name, int phoneNumber, string nIC, string gender, string email);
    void SetRegisteruserDetails(string Name, int phoneNumber, string nIC, string gender, string email);
    void DisplayRegisteredDetails();
    void addIssue(Issue* is1, string issue);
    ~RegisteredUser();
};

