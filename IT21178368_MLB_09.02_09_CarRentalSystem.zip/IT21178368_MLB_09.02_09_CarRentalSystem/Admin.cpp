#include "Admin.h"
//default cunstructor

Admin::Admin() {

    AdminID = 0;
    AdminName = "";
    ContactNumber = 0;
    Gender = "";
    NIC = "";
    AdminEmail = "";

};

//cunstructors with parameters

Admin::Admin(int adID, string adName, int Cnumber, string gen, string nic, string adEmail) {

    AdminID = adID;
    AdminName = adName;
    ContactNumber = Cnumber;
    Gender = gen;
    NIC = nic;
    AdminEmail = adEmail;

};

void Admin::SendNoitifications(Driver* reciever, string notification) {
    Notification newNoti(reciever, notification);
    newNoti.sendNotification();
}



void Admin::SetAdminDetails() {
    int AdminID;
    string AdminName;
    int ContactNumber;
    string Gender;
    string NIC;
    string AdminEmail;

    cout << "Add Admin Details" << endl;
    cout << "Enter Admin ID:\t" << endl;
    cin >> AdminID;
    cout << "Enter admin name:\t" << endl;
    cin >> AdminName;
    cout << "Enter contact number:\t" << endl;
    cin >> ContactNumber;
    cout << "Enter gender:\t" << endl;
    cin >> Gender;
    cout << "Enter National Identity Card number:\t" << endl;
    cin >> NIC;
    cout << "Enter admin email:\t" << endl;
    cin >> AdminEmail;

};

void Admin::DisplayAdminDetails() {
    cout << "...Admin Details..." << endl;
    cout << "Admin ID : " << AdminID << endl;
    cout << "Name : " << AdminName << endl;
    cout << "Contact Number : " << ContactNumber << endl;
    cout << "Gender : " << Gender << endl;
    cout << " NIC : " << NIC << endl;
    cout << "Email : " << AdminEmail << endl;
};

