#pragma once
#include <iostream>
#include <string>
#include "RegisteredUser.h"
#include "Report.h"
#include "Notification.h"
using namespace std;

class Admin {
private:
    int AdminID;
    string AdminName;
    int ContactNumber;
    string Gender;
    string NIC;
    string AdminEmail;


public:
    Admin();
    Admin(int adID, string adName, int Cnumber, string gen, string nic, string adEmail);
    void SetAdminDetails();
    void UpdateAdminDetails();
    void DisplayAdminDetails();
    void CreateFAQ();
    void UpdateWholeSystem();
    void SendNoitifications(Driver* reciever, string notification);
    Report GenerateReports(Reservation reservation[], int size);

};


