#include "CardPayment.h"

//default cunstructor
CardPayment::CardPayment() {

    CardType = "";
    CardNumber = 0;
    ExpirationMonth = "";
    ExpirationYear = 0;
    CVNumber = 0;

};

//cunstructors with parameters
CardPayment::CardPayment(string ctype, int cnumber, string exmonth, int exyear, int cvno) {

    CardType = ctype;
    CardNumber = cnumber;
    ExpirationMonth = exmonth;
    ExpirationYear = exyear;
    CVNumber = cvno;

};
