#pragma once
#include <iostream>
#include <string>

using namespace std;

class Paymet
{
protected:

    float  PyamentValue;
    int PaymentID;
    string PaymentType;
public:

    Paymet();
    Paymet(float  paymentValue, int paymentID, string paymentType);
    void CalPayment();
    void displayPaymentDetails();
    void StorePayementDetails();

    ~Paymet();
};

class CardPayment : public Paymet {
private:
    string CardType;
    int CardNumber;
    string ExpirationMonth;
    int ExpirationYear;
    int CVNumber;

public:
    CardPayment();
    CardPayment(string ctype, int cnumber, string exmonth, int         exyear, int cvno);
    void StoreCardpaymentDetails();
    void GetCardpaymentDetails();
    ~CardPayment();
};
