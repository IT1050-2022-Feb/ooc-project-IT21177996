#include "Feedback.h"

//Default cunstractor 
Feedback::Feedback() {
    feedbackID = 0;
    feedback = "";
};

//cunstructor with parameters
Feedback::Feedback(int feedID, string feedb) {
    feedID = feedbackID;
    feedb = feedback;
};
