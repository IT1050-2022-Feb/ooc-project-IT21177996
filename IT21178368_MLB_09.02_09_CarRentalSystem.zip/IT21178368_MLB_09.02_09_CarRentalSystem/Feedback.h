#pragma once
#include <iostream>
#include <string>
using namespace std;

class Feedback {
private:
    int feedbackID;
    string feedback;

public:
    Feedback();
    Feedback(int feedID, string feedb);
    void StoreFeedbackDetails();
    void ViewFeedbackDetails();
};

