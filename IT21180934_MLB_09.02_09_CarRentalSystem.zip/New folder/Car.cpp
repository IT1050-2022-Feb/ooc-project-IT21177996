#include "Car.h"

Car::Car(string registrationNumber, string insuranceName, string expireDate, string manufaturerName, string modelName,float pricePerDay)
{
	this->registrationNumber = registrationNumber;
	this->insurance = new Insurance(insuranceName, expireDate);
	this->manufacturerName = manufaturerName;
	this->modelName = modelName;
}
float Car::getPricePerDay(){
  return pricePerDay;
}
string Car::getManufacturerName(){
  string manufacturersName;
}
void Car::updateInsurance(string expireDate) {
	insurance->updateExpiryDate(expireDate);
}
string Car::getModelName(){
  return modelName;
}
void Car::displayCarDetails() {
	cout << "Registration number: " << registrationNumber << endl;
	cout << "Manufaturer Name: " << manufacturerName << endl;
	cout << "Model Name : " << modelName << endl;
	insurance->displayInsuranceDetails();

}
Car::~Car(){
  delete insurance;
}
