#include <iostream>
#include "Insurance.h"
using namespace std;
class Car {
private:
  float pricePerDay;
	string registrationNumber;
	Insurance *insurance;
	string manufacturerName;
	string modelName;
public:

	Car(string registrationNumber, string insuranceName, string expireDate,string manufacturerName,string modelName,float pricePerDay);
  float getPricePerDay();
	void updateInsurance(string expireDate);
	void displayCarDetails();
  string getManufacturerName();
  string getModelName();
  ~Car();
};




