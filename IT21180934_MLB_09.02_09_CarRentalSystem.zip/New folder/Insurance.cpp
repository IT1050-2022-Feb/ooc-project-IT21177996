
#include "Insurance.h"

Insurance::Insurance(string insuranceName, string expireDate) {

}

void Insurance::updateExpiryDate(string expireDate){
	this->expireDate = expireDate;
	cout << "insurance date has been updated to " << expireDate << "."<<endl;
}


void Insurance::displayInsuranceDetails()
{
	cout << "Insurance name: " << insuranceName<<endl;
	cout << "Insurance expire date: " << expireDate << endl;

}


