#include<iostream>
using namespace std;
class Insurance {
private:
	string insuranceName;
	string expireDate;
public:
	Insurance(string insuranceName, string expireDate);
	void updateExpiryDate(string expireDate);
	void displayInsuranceDetails();	
};