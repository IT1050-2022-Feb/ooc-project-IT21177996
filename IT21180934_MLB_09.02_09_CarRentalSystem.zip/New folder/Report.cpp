#include "Report.h"
 Report::Report(Reservation reservation[],int rows){
      this->rows = rows;
      float total = 0;
      int i;
      nameList = new string[rows];
      valueList = new float[rows];
      for(i=0;i<rows;i++){
        nameList[i] = reservation[i].getCustomerName();
        valueList[i] = reservation[i].getTotal();
        total += valueList[i];
      }
    }

void Report::printReport(){
  int i;
  for(i=0;i<rows;i++){
    cout<<nameList[i]<<"\t"<<valueList[i]<<endl;
    
  }
  cout<<"Total = \t"<<total<<endl;
}