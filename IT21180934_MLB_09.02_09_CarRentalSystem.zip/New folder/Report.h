#include<iostream>
#include "Reservation.h"
using namespace std;

class Report{
  private:
    string *nameList;
    float *valueList;
    int rows;
    float total;
  public:
    Report();
    Report(Reservation reservation[],int rows);    
    void printReport();
};
