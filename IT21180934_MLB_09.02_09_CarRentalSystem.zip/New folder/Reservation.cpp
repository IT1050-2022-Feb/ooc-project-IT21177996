
#include <iostream>
#include<string>
#include "Reservation.h"


Reservation::Reservation(int customerId,string customerName,string pickupDate,string dropOffDate,int numberOfDates) {
  payment = 0;
  this->customerId = customerId;
  this->customerName = customerName;
  this->pickupDate = pickupDate;
  this->dropOffDate = dropOffDate;
  this->numberOfDates = numberOfDates;
  
}
bool Reservation::validateCustomer(int id){
  if(customerId == id)
    return true;
  if(customerId == -112567){
    cout<<"You are using admin privileges, Be Responsible!!!"<<endl;//for admins.
    return true;
  }
     
  else
    cout<<"You are not allowed to manipulate other customers reservations"<<endl;
    return false;
}
bool Reservation::validateDriver(int id){
  if(driverId == id)
    return true;
  else
    return false;
}
float Reservation::getTotal(){
  return total;
}
string Reservation::getCustomerName(){
  return customerName;
}

void Reservation::postponeReservation(string pickUpDate,int id){
  if(validateCustomer(id)){
    this->pickupDate = pickUpDate;
    cout<<"reservation postponed!!"<<endl;
  }
}
void Reservation::extendReservation(string dropOffDate,int id){
  if(validateCustomer(id)){
    this->dropOffDate = dropOffDate;
    cout<<"reservation extended!!"<<endl;
  }
}
void Reservation::calculateAndSetTotal(){
  total = car->getPricePerDay()*numberOfDates;
}
void Reservation::addADriver(Driver driver,int id){
  if(validateCustomer(id)){
    this->driverId = driver.getDriverId();
    total += 1000*numberOfDates;
  }
}
void Reservation::displayPaymentDetails(int id){
  if(validateCustomer(id)){    
  
    if(payment!= 0){
      payment->displayPaymentDetails();
    }else{
      cout<<"Haven't paid yet!!!"<<endl;
    }
  }
}
void Reservation::changeCar(Car *newCar,int id){
    if(validateCustomer(id)){
      car = newCar;
    }
}
void Reservation::printReservationDetails(){
  cout<<"Car:\t"<<car->getManufacturerName()<<" "<<car->getModelName()<<endl;
}



