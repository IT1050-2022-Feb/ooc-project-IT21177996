#pragma once
#include<iostream>
#include"Payment.h"
#include "Car.h"

class Reservation {
private:
	
	Car *car;
  int customerId;
	string customerName;
	string pickupDate;
	string dropOffDate;
	Payment *payment;
	int driverId;
  float total;
  int numberOfDates;
public:  
  Reservation(int customerId,string customerName,string pickupDate,string dropOffDate,int numberOfDates);
	void postponeReservation(string pickUpDate,int id);
	void extendReservation(string dropOffDate,int id);
	void changeCar(Car *newCar,int id);
	void displayPaymentDetails(int id);
  string getCustomerName();
  float getTotal();
  void printReservationDetails();
  void addADriver(Driver driver, int id);
  bool validateDriver(int id);
  bool validateCustomer(int id);
  void calculateAndSetTotal();
  void addAPayment(Payment *payment);
  ~Reservation(){
    delete payment;
  }
  
};
;

