#include "FAQ.h"
#include<iostream>
#include<string>

//Default cunstructor 
       
      FAQ::FAQ(){
      FAQID = 0;
      FAQ = "";

};

 //Cunstructor with parameters

      FAQ::FAQ(int FAQID, string FAQ) {
          FAQID = FAQID;
          FAQ = FAQ;

 };
     

