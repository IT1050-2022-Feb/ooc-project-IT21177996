#pragma once
#include<iostream>
#include<string>
using namespace std;

class FAQ {
     private:
         int FAQID;
         string FAQ;

public:
    FAQ();
    FAQ(int FAQID, string FAQ);
    void StoreFAQDetails();
    void UpdateFAQDetails();
    void ReadFAQ();
};
