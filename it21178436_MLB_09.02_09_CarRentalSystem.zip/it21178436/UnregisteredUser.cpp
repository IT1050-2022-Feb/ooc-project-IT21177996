#include "UnregisteredUser.h"
#include "Customer.h"
#include<iostream>
#include<string>

//Driver(int accountNumber, string licenNumber, string address, string bankName );
Driver* UnregisteredUser::registerAsADriver(){
  int accountNumber;
  string licenseNumber;
  string address;
  string bankName;
  cout<<"Register as a driver............."<<endl;
  cout<<"Enter account number:\t"<<endl;
  cin>>accountNumber;
  cout<<"Enter license number:\t"<<endl;
  cin>>licenseNumber;
  cout<<"Enter address:\t"<<endl;
  cin>>address;
  cout<<"Enter bank name:\t"<<endl;
  cin>>bankName;
  Driver*driver = new Driver(accountNumber,licenseNumber,address,bankName);
  return driver;
}
Customer* UnregisteredUser::registerAsACustomer(){
  Customer* customer = new Customer();
  return customer;
}
void Customer::viewCar(Car* car){
  car->viewCarDetails();
}
      
      

