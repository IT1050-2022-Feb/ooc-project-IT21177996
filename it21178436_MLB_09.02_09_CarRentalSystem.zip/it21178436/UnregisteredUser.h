#include<iostream>
#include<string>
#include "Driver.h"
#include "Customer.h"
#include "Car.h"
using namespace std;

class UnregisteredUser{
public:
   //Driver(int accountNumber, string licenNumber, string address, string bankName );
    Driver* registerAsADriver();
    Customer* registerAsACustomer();
    void viewCar(Car* car);
};

    

