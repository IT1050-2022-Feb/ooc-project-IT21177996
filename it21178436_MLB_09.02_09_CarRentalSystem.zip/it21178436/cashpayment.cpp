#include "CashPayment.h"
#include<iostream>
#include<string>


       
CashPayment::CashPayment(){
    Location = "";

};

 

CashPayment::CashPayment(string Location) {
  
    Location = Location;

 };

    void CashPayment::SetCashPaymentDetails(){

 }
  void CashPayment::DisplayCashPaymentDetails(){

      cout << "Location : " <<  Location  << endl;
  }

    void CashPayment::UpdateCashPaymentDetails(){
      
    }

