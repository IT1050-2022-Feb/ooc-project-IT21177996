#pragma once
#include<iostream>
#include<string> 
using namespace std;

#include "Payment.h"

class CashPayment : public payment {
     protected:
         string Location;
         

public:
    CashPayment();
    CashPayment(string Location);
    void setCashPaymentDetails();
    void DisplayCashPaymentDetails();
    void UpdateCashPaymentDetails();


};

